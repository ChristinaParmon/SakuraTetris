package com.example.tetris
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

class GameActivity: AppCompatActivity()  {
}